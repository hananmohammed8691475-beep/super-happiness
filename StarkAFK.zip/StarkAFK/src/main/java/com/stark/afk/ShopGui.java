package com.stark.afk;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ShopGui implements Listener {
    public enum Mode { BUY, REMOVE, SETPRICE }

    private static final int CONFIRM_SIZE = 27; // confirm menu is always 3 rows

    private static class Holder implements InventoryHolder {
        int page; Mode mode; long price; Inventory inv;
        @Override public @NotNull Inventory getInventory() { return inv; }
    }

    private static final int CONFIRM_NO_SLOT = 11;
    private static final int CONFIRM_ITEM_SLOT = 13;
    private static final int CONFIRM_YES_SLOT = 15;

    private static class ConfirmHolder implements InventoryHolder {
        int page; Mode mode; long price; ShopManager.Entry entry; Inventory inv;
        @Override public @NotNull Inventory getInventory() { return inv; }
    }

    private final AfkPlugin plugin;

    public ShopGui(AfkPlugin plugin) { this.plugin = plugin; }

    // ---- layout (read live from config.yml -> "shop" section, so /afk reload applies it) ----

    private int rows() {
        return Math.max(1, Math.min(6, plugin.getConfig().getInt("shop.rows", 3)));
    }

    private Material filler() {
        Material m = Material.matchMaterial(plugin.getConfig().getString("shop.filler-material", "GREEN_STAINED_GLASS_PANE"));
        return m != null ? m : Material.GREEN_STAINED_GLASS_PANE;
    }

    private int prevSlot() { return plugin.getConfig().getInt("shop.previous-slot", 18); }
    private int nextSlot() { return plugin.getConfig().getInt("shop.next-slot", 26); }

    private int totalPages(List<ShopManager.Entry> list) {
        int max = 1;
        for (ShopManager.Entry e : list) max = Math.max(max, e.page);
        return max;
    }

    public void open(Player p, int page, Mode mode, long price) {
        List<ShopManager.Entry> list = plugin.getShop().getEntries();
        int size = rows() * 9;
        int pages = totalPages(list);
        page = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder();
        h.page = page; h.mode = mode; h.price = price;
        long bal = plugin.getShards().get(p.getUniqueId());
        h.inv = Bukkit.createInventory(h, size, plugin.mc("gui.title", "balance", String.valueOf(bal)));

        // 1) glass everywhere
        ItemStack glass = named(filler(), " ");
        for (int i = 0; i < size; i++) h.inv.setItem(i, glass);

        // 2) each item replaces the glass at the slot written in shop.yml
        for (ShopManager.Entry e : list) {
            if (e.page != page + 1 || e.slot < 0 || e.slot >= size) continue;
            h.inv.setItem(e.slot, display(e, mode));
        }

        // 3) page arrows (never over an item)
        int prev = prevSlot(), next = nextSlot();
        if (page > 0 && prev >= 0 && prev < size && !isItemSlot(list, page + 1, prev))
            h.inv.setItem(prev, named(Material.ARROW, plugin.m("gui.previous-page")));
        if (page < pages - 1 && next >= 0 && next < size && !isItemSlot(list, page + 1, next))
            h.inv.setItem(next, named(Material.ARROW, plugin.m("gui.next-page")));
        p.openInventory(h.inv);
    }

    private boolean isItemSlot(List<ShopManager.Entry> list, int page1, int slot) {
        for (ShopManager.Entry e : list) if (e.page == page1 && e.slot == slot) return true;
        return false;
    }

    private ShopManager.Entry entryAt(List<ShopManager.Entry> list, int page1, int slot) {
        for (ShopManager.Entry e : list) if (e.page == page1 && e.slot == slot) return e;
        return null;
    }

    private void openConfirm(Player p, ShopManager.Entry entry, Holder h) {
        ConfirmHolder c = new ConfirmHolder();
        c.page = h.page; c.mode = h.mode; c.price = h.price; c.entry = entry;
        c.inv = Bukkit.createInventory(c, CONFIRM_SIZE, plugin.mc("gui.confirm-title"));

        ItemStack glass = named(filler(), " ");
        for (int i = 0; i < CONFIRM_SIZE; i++) c.inv.setItem(i, glass);

        ItemStack shown = entry.item.clone();
        ItemMeta m = shown.getItemMeta();
        List<Component> lore = m.lore() != null ? new ArrayList<>(m.lore()) : new ArrayList<>();
        lore.add(Component.empty());
        lore.add(plugin.mc("gui.price", "price", String.valueOf(entry.price)));
        m.lore(lore);
        shown.setItemMeta(m);

        c.inv.setItem(CONFIRM_NO_SLOT, named(Material.RED_STAINED_GLASS_PANE, plugin.m("gui.confirm-no")));
        c.inv.setItem(CONFIRM_ITEM_SLOT, shown);
        c.inv.setItem(CONFIRM_YES_SLOT, named(Material.LIME_STAINED_GLASS_PANE, plugin.m("gui.confirm-yes")));
        p.openInventory(c.inv);
    }

    @EventHandler
    public void onConfirmClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ConfirmHolder c)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getSlot();
        if (slot == CONFIRM_NO_SLOT) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
            plugin.send(p, "gui.cancelled");
            open(p, c.page, c.mode, c.price);
        } else if (slot == CONFIRM_YES_SLOT) {
            if (!plugin.getShop().getEntries().contains(c.entry)) {
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                open(p, c.page, c.mode, c.price);
                return;
            }
            Holder h = new Holder();
            h.page = c.page; h.mode = c.mode; h.price = c.price;
            buy(p, c.entry, h);
        }
    }

    @EventHandler
    public void onConfirmDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ConfirmHolder) e.setCancelled(true);
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(AfkPlugin.c(name));
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack display(ShopManager.Entry e, Mode mode) {
        ItemStack d = e.item.clone();
        ItemMeta m = d.getItemMeta();
        List<Component> lore = m.lore() != null ? new ArrayList<>(m.lore()) : new ArrayList<>();
        lore.add(Component.empty());
        lore.add(plugin.mc("gui.price", "price", String.valueOf(e.price)));
        switch (mode) {
            case BUY -> lore.add(plugin.mc("gui.click-buy"));
            case REMOVE -> lore.add(plugin.mc("gui.click-remove"));
            case SETPRICE -> lore.add(plugin.mc("gui.click-setprice"));
        }
        m.lore(lore);
        d.setItemMeta(m);
        return d;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getSlot();
        ItemStack cur = e.getCurrentItem();
        if (slot == nextSlot() && cur != null && cur.getType() == Material.ARROW) {
            open(p, h.page + 1, h.mode, h.price);
            return;
        }
        if (slot == prevSlot() && cur != null && cur.getType() == Material.ARROW) {
            open(p, h.page - 1, h.mode, h.price);
            return;
        }
        List<ShopManager.Entry> list = plugin.getShop().getEntries();
        ShopManager.Entry entry = entryAt(list, h.page + 1, slot);
        if (entry == null) return; // glass

        switch (h.mode) {
            case REMOVE -> {
                list.remove(entry);
                plugin.getShop().save();
                plugin.send(p, "gui.removed");
                open(p, h.page, h.mode, h.price);
            }
            case SETPRICE -> {
                entry.price = h.price;
                plugin.getShop().save();
                plugin.send(p, "gui.price-set", "price", String.valueOf(h.price));
                open(p, h.page, h.mode, h.price);
            }
            case BUY -> { if (canBuy(p, entry)) openConfirm(p, entry, h); }
        }
    }

    private boolean canBuy(Player p, ShopManager.Entry entry) {
        long bal = plugin.getShards().get(p.getUniqueId());
        if (bal < entry.price) {
            plugin.send(p, "gui.not-enough", "price", String.valueOf(entry.price));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }
        Inventory temp = Bukkit.createInventory(null, 36);
        temp.setContents(p.getInventory().getStorageContents().clone());
        if (!temp.addItem(entry.item.clone()).isEmpty()) {
            plugin.send(p, "gui.inventory-full");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }
        return true;
    }

    private void buy(Player p, ShopManager.Entry entry, Holder h) {
        if (!canBuy(p, entry)) return;
        plugin.getShards().take(p.getUniqueId(), entry.price);
        p.getInventory().addItem(entry.item.clone());
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        plugin.send(p, "gui.purchased", "price", String.valueOf(entry.price));
        open(p, h.page, h.mode, h.price);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
